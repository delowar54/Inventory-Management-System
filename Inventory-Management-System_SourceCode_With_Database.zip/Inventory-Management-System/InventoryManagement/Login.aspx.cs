﻿using System;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    SQLCommand sqlcon = new SQLCommand();
    //static SqlConnection sqlcon = new SqlConnection(@"Data Source=ASITDEV12\SQL2K19ENT;initial Catalog=InventoryMangement;User ID=sa;Password=1234;Connect Timeout=120; Max Pool Size=200");
    //Data Source=ASITDEV12\SQL2K19ENT;initial Catalog=InventoryMangement;User ID=sa;Password=1234;Connect Timeout=120; Max Pool Size=200
    //C:\Program Files\Microsoft SQL Server\MSSQL15.SQL2K19ENT\MSSQL\DATA
    //Data Source =ASITDEV12\SQL2K19ENT;Initial Catalog=InventoryMangement;Integrated Security=true
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        sqlcon.conchck();
        string checkquery = "Select count(1) from  UserInf where Username='"+txtUserName.Text+"' and Password='"+txtPassword.Text.Trim()+"'";
        SqlCommand cmd = new SqlCommand(checkquery, sqlcon.sqlcon);
        int count = Convert.ToInt32(cmd.ExecuteScalar());
        if (count == 1)
        {
            //lblerror.Text = "login Successful!";

            Session["user"] = txtUserName.Text.Trim();
            Response.Redirect("Home.aspx");
            
        }
        else
        {
            lblerror.Text = "Login Failed. Incorrect Username or Password!";
        }
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        txtUserName.Text = "";
        txtPassword.Text = "";
    }
}