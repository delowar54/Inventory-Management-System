﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for SQLCommand
/// </summary>
public class SQLCommand
{
   public SqlConnection sqlcon = new SqlConnection(@"Data Source=ASITDEV12\SQL2K19ENT;initial Catalog=InventoryMangement;User ID=sa;Password=1234;Connect Timeout=120; Max Pool Size=200");

    public SQLCommand()
    {

    }
    public void conchck()
    {
        if (this.sqlcon.State == System.Data.ConnectionState.Open)
        {
            this.sqlcon.Close();
        }
        this.sqlcon.Open();
    }
}