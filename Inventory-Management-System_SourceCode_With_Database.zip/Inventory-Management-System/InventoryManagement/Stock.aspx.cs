﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;

public partial class Stock : System.Web.UI.Page
{
    static SQLCommand constr = new SQLCommand();
    static SqlDataAdapter daAd;
    static DataTable datbl;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("LoginPage.aspx");
        }
        else if (!IsPostBack)
        {
            stockitem();
        }
        
    }
    protected void stockitem()
    {
        constr.conchck();

        string query = "select Product.ProductName,Supplier.CompanyName, Sum(Purchase.Quantity) as total from Product inner join Purchase on Product.ProductId = Purchase.ProductId inner join Supplier on Purchase.SupplierId = Supplier.SupplierId group by product.ProductName, Supplier.CompanyName";
        SqlDataAdapter sqlDa = new SqlDataAdapter(query, constr.sqlcon);

        DataSet ds = new DataSet();
        sqlDa.Fill(ds);

        stockGrid.DataSource = ds;
        stockGrid.DataBind();
    }
    protected void purchaseGrid_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}