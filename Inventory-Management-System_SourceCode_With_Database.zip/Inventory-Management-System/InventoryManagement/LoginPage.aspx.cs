﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class LoginPage : System.Web.UI.Page
{
    SQLCommand sqlcon = new SQLCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        sqlcon.conchck();
        string checkquery = "Select count(1) from UserInf where Username='" + txtUserName.Value.Trim() + "' and Password='" + txtPassword.Value.Trim() + "'";
        SqlCommand cmd = new SqlCommand(checkquery, sqlcon.sqlcon);
        int count = Convert.ToInt32(cmd.ExecuteScalar());
        if (count == 1)
        {
            //lblerror.Text = "login Successful!";

            Session["user"] = txtUserName.Value.Trim();
            Response.Redirect("Home.aspx");

        }
        else
        {
            //lblerror.Text = "Login Failed. Incorrect Username or Password!";
        }
    }
}