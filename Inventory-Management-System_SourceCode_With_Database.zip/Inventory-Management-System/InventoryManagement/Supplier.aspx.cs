﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Supplier : System.Web.UI.Page
{
    //SqlConnection sqlcon = new SqlConnection(@"Data Source =ASITDEV12\SQL2K19ENT;Initial Catalog=InventoryMangement;Integrated Security=true");
    SQLCommand sqlcon = new SQLCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("LoginPage.aspx");
        }
        else if (!IsPostBack)
        {
            btndelete.Enabled = false;
            FillGridView();
        }
    }
    void FillGridView()
    {
        sqlcon.conchck();
        SqlDataAdapter sqlDa = new SqlDataAdapter("SupplierViewAll", sqlcon.sqlcon);
        sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);
        supplierGrid.DataSource = dtbl;
        supplierGrid.DataBind();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        sqlcon.conchck();
        SqlCommand sqlcmd = new SqlCommand("SupplierCreateOrUpdate", sqlcon.sqlcon);
        sqlcmd.CommandType = CommandType.StoredProcedure;
        sqlcmd.Parameters.AddWithValue("@SupplierId", hfSupplierId.Value == "" ? 0 : Convert.ToInt32(hfSupplierId.Value));
        sqlcmd.Parameters.AddWithValue("@CompanyName", txtComName.Text.Trim());
        sqlcmd.Parameters.AddWithValue("@TradeNo", txtTradeLiNo.Text.Trim());
        sqlcmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text.Trim());
        sqlcmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
        sqlcmd.ExecuteNonQuery();
        string SupplierId = hfSupplierId.Value;
        clear();

        if (SupplierId == "")
            lblsuccessmassage.Text = "Saved Successfully";
        else
            lblsuccessmassage.Text = "Updated Successfully";
        FillGridView();
    }
    protected void lnk_onClick(object sender, EventArgs e)
    {
        int SupplierId = Convert.ToInt32((sender as LinkButton).CommandArgument);

        sqlcon.conchck();
        SqlDataAdapter sqlDa = new SqlDataAdapter("SupplierViewById", sqlcon.sqlcon);
        sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
        sqlDa.SelectCommand.Parameters.AddWithValue("@SupplierId", SupplierId);
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);
        hfSupplierId.Value = SupplierId.ToString();
        txtComName.Text = dtbl.Rows[0]["CompanyName"].ToString();
        txtTradeLiNo.Text = dtbl.Rows[0]["TradeNo"].ToString();
        txtMobileNo.Text = dtbl.Rows[0]["MobileNo"].ToString();
        txtAddress.Text = dtbl.Rows[0]["Address"].ToString();
        btnsave.Text = "Update";
        btndelete.Enabled = true;
    }

    protected void btnclear_Click(object sender, EventArgs e)
    {
        hfSupplierId.Value = "";
        txtComName.Text = txtAddress.Text = txtMobileNo.Text = txtTradeLiNo.Text = "";

        lblerrormessage.Text = lblsuccessmassage.Text = "";
        btnsave.Text = "Save";
        btndelete.Enabled = true;
    }
    public void clear()
    {
        
    }


    protected void btndelete_Click(object sender, EventArgs e)
    {
        sqlcon.conchck();
        SqlCommand sqlcmd = new SqlCommand("SupplierDeleteById", sqlcon.sqlcon);
        sqlcmd.CommandType = CommandType.StoredProcedure;
        sqlcmd.Parameters.AddWithValue("@SupplierId", Convert.ToInt32(hfSupplierId.Value));
        sqlcmd.ExecuteNonQuery();
        clear();
        FillGridView();
        lblsuccessmassage.Text = "Deleted Successfully";
    }
}