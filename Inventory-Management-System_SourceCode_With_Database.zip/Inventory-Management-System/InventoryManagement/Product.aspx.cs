﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Product : System.Web.UI.Page
{
    SQLCommand constr = new SQLCommand();
    //SqlConnection sqlcon = new SqlConnection(@"Data Source =ASITDEV12\SQL2K19ENT;Initial Catalog=InventoryMangement;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("LoginPage.aspx");
        }
        else if (!IsPostBack)
        {
            btndelete.Enabled = false;
            FillGridView();
        }
    }

    protected void btnclear_Click(object sender, EventArgs e)
    {
        this.clear();
    }

    public void clear()
    {
        hfProductId.Value = "";
        txtproname.Text = txtprodes.Text = "";
        lblerrormessage.Text = lblsuccessmassage.Text = "";
        btnsave.Text = "Save";
        btndelete.Enabled = true;

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {


        constr.conchck();
        SqlCommand sqlcmd = new SqlCommand("ProductCreateOrUpdate", constr.sqlcon);
        sqlcmd.CommandType = CommandType.StoredProcedure;
        sqlcmd.Parameters.AddWithValue("@ProductId", hfProductId.Value == "" ? 0 : Convert.ToInt32(hfProductId.Value));
        sqlcmd.Parameters.AddWithValue("@ProductName", txtproname.Text.Trim());
        sqlcmd.Parameters.AddWithValue("@ProductDescription", txtprodes.Text.Trim());
        sqlcmd.ExecuteNonQuery();
        string ProductId = hfProductId.Value;
        clear();

        if (ProductId == "")
            lblsuccessmassage.Text = "Saved Successfully";
        else
            lblsuccessmassage.Text = "Updated Successfully";
        FillGridView();
    }

    void FillGridView()
    {

        constr.conchck();
        SqlDataAdapter sqlDa = new SqlDataAdapter("ProductViewAll", constr.sqlcon);
        sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);
        productGrid.DataSource = dtbl;
        productGrid.DataBind();
    }

    protected void lnk_onClick(object sender, EventArgs e)
    {
        int ProductId = Convert.ToInt32((sender as LinkButton).CommandArgument);
        
            constr.conchck();
        SqlDataAdapter sqlDa = new SqlDataAdapter("ProductViewById", constr.sqlcon);
        sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
        sqlDa.SelectCommand.Parameters.AddWithValue("@ProductId", ProductId);
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);
        hfProductId.Value = ProductId.ToString();
        txtproname.Text = dtbl.Rows[0]["ProductName"].ToString();
        txtprodes.Text = dtbl.Rows[0]["ProductDescription"].ToString();
        btnsave.Text = "Update";
        btndelete.Enabled = true;
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
            constr.conchck();
        SqlCommand sqlcmd = new SqlCommand("ProductDeleteById", constr.sqlcon);
        sqlcmd.CommandType = CommandType.StoredProcedure;
        sqlcmd.Parameters.AddWithValue("@ProductId", Convert.ToInt32(hfProductId.Value));
        sqlcmd.ExecuteNonQuery();
        clear();
        FillGridView();
        lblsuccessmassage.Text = "Deleted Successfully";
    }
}